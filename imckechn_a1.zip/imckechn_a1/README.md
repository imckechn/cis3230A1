# cis3230A1

### Fall 2022

A basic ruby program where we are just writing classes for a game, not supposed to have a program calling them, just a helper class that tests everything.

### Intent of Program
It's a game where a player can put either (or both) dice and a coin into a hand, cup, or bag, and then role/flip them and get random results back. It's supposed to emulate really life.

### Asumptions
In player.rb
If you move objects between the bag and the cup and vise versa, if the coin/die doesnt have a description, it will automatically be counted


### Also
I my randomizer.results broke right before I was supposed to submit. This is cause my SUM and possibly Tally function to fail. Please be aware as the tally adn sum methods work, but they rely on the results function and it's broken. This makes results appear broken. Thanks and hope this helps.